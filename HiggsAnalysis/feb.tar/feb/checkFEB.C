#include "checkFEB.h"

bool passElectron(double eta, double phi, double dR)
{
  return !((eta < 1.45+dR && eta > 0-dR) && (phi < -0.592+dR && phi > -0.788-dR));
}
bool passJet(double eta, double phi, double dR)
{
  return !((eta < 1.45+dR && eta > 0-dR) && (phi < -0.592+dR && phi > -0.788-dR));
}
